<?php 
echo "<script>alert('Logined Successfuly Buka lagi menu Chating dan mulai chat dengan kawan kalian!')</script>";
header("refresh:1; url=dashboard_admin.php");
?>