<footer class="py-4 bg-light mt-auto p-fixed" style="position: fixed; bottom: 0; width: 100%;">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-center small">
            <div class="text-muted">Copyright &copy; Sena Pernata 2023
            </div>
        </div>
    </div>
</footer>